
public class Faculty {

	String officeHours;
	String rank;
	String name;

	public String getRank() {

		return rank;
	}


	public void setRank(String rank) {

		this.rank = rank;

	}



	public String getHours() {

		return officeHours;
	}


	public void setHours(String officeHours) {

		this.officeHours = officeHours;
	}

	public String getName() {
		
		return name;
	}
	
	public void setName(String name) {
		
		this.name = name;
		
	}
	

	public String toString() {

		return super.toString() + "Faculty " + "hours = " + officeHours + ", rank = " + rank;		
	}
	
}
