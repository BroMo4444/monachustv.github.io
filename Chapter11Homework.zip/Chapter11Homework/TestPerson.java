
public class TestPerson {

	
	
	public static void main(String[] args) {
		
		Person person = new Person();
		person.setName("Gerald");
		
		Student student = new Student();
		student.setName("Abby");
		student.setStatus(3);
		
		Employee employee = new Employee();
		employee.setName("Armin");
		
		
		Faculty faculty = new Faculty();
		faculty.setRank("Secretary");
		faculty.setHours("Monday-Friday, 8a-5p");
		faculty.setName("Kaleb");
		
		Staff staff = new Staff();
		staff.setName("Jenny");
		staff.setTitle("Assistant");
		
		
		System.out.println("Person: " + person);
		System.out.println("Student: " + student);
		System.out.println("Employee: " + employee);
		System.out.println("Faculty: " + faculty);
		System.out.println("Staff: " + staff);
		
		
		}
	
}
