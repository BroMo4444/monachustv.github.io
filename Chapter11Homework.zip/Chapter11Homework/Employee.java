
public class Employee extends Person {

	
	String office;
	int salary;
	String dateHired = "07/23/1998";

	public String getOffice() {

		return office;
	}


	public void setOffice(String office) {

		this.office=office;
	}

	public int getSalary() {
		return salary;

	}

	public void setSalary(int salary) {

		this.salary=salary;
	}


	public String toString() {

		return super.toString() + "Employee " + "office = " + office + ", salary = " + salary + ", date hire = " + dateHired;

	}
	
}
