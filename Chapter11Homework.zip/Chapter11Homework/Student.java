
public class Student extends Person{


	int senior = 1;
	int sophomore = 2;
	int freshman = 3;
	int status = 1;



	public int getStatus() {

		return status;
	}

	public void setStatus(int status) {

		this.status=status;
	}


	public String toString() {

		return super.toString()+ "Student status = " + status;
	}


}
	

